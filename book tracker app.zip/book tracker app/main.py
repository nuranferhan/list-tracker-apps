import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
import json

class BookRecordApplication:

    def __init__(self, root):
        self.root = root
        self.root.title("Book Reading Tracker")
        self.root.geometry("800x600")
        self.root.minsize(800, 600)

        # Load background image
        self.background_image = Image.open("background.jpg")
        self.background_photo = None
        self.background_label = tk.Label(self.root)
        self.background_label.place(x=0, y=0, relwidth=1, relheight=1)

        self.book_list = []
        self.reverse_sort = False

        # Title
        self.title_label = tk.Label(self.root, text="Book Registration App", bg="#5f262c", fg="#ecf0f1",
                                     font=("Helvetica", 16, "bold"), pady=10)
        self.title_label.pack(fill=tk.X)

        # Create UI elements
        self.create_interface()
        self.load_data()

        # Update background when window is resized
        self.root.bind("<Configure>", self.apply_background)
        self.apply_background(None)

        # Clear button
        self.clear_button = tk.Button(self.root, text="Clear", command=self.clear_book_list,
                                      bg="#4f5263", fg="white", font=("Helvetica", 10))
        self.clear_button.place(relx=0.0, x=10, y=10, anchor="nw")

    def clear_book_list(self):
        self.book_list.clear()  # Clear the book list
        self.update_list()  # Update the list on the UI

        messagebox.showinfo("Clear", "The list has been successfully cleared.")

    def apply_background(self, event):
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        resized_image = self.background_image.resize((width, height), Image.LANCZOS)
        self.background_photo = ImageTk.PhotoImage(resized_image)
        self.background_label.config(image=self.background_photo)

    def create_interface(self):
        # Create a frame for the search bar
        self.search_frame = tk.Frame(self.root, bg="#b76e4e", pady=10)
        self.search_frame.pack(fill=tk.X, pady=10, padx=10)

        # Add "Search" label and entry box
        self.search_label = tk.Label(self.search_frame, text="Search:", bg="#b76e4e", fg="#ecf0f1", font=("Helvetica", 10))
        self.search_label.grid(row=0, column=0, padx=5, pady=5)
        self.search_entry = tk.Entry(self.search_frame, bg="#ecf0f1", fg="#2c3e50", font=("Helvetica", 10), width=30)
        self.search_entry.grid(row=0, column=1, padx=5, pady=5)

        # Add label and combobox for genre selection
        self.genre_label = tk.Label(self.search_frame, text="Genre:", bg="#b76e4e", fg="#ecf0f1", font=("Helvetica", 10))
        self.genre_label.grid(row=0, column=2, padx=5, pady=5)
        self.search_genre_combobox = ttk.Combobox(self.search_frame, values=["Memoir", "Novel", "Story", "Travel", "Poetry", "Biography", "Information", "Religion", "Children", "All Genres"],
                                               state="readonly")
        self.search_genre_combobox.set("All Genres")
        self.search_genre_combobox.grid(row=0, column=3, padx=5, pady=5)

        # Add Search and Clear buttons
        self.search_button = tk.Button(self.search_frame, text="Search", command=self.filter, bg="#4f5263", fg="#ecf0f1",
                                      font=("Helvetica", 10))
        self.search_button.grid(row=0, column=4, padx=5, pady=5)
        self.clear_button = tk.Button(self.search_frame, text="Clear", command=self.clear, bg="#c0392b",
                                        fg="#ecf0f1", font=("Helvetica", 10))
        self.clear_button.grid(row=0, column=5, padx=5, pady=5)

        # Create a frame to display the book list
        self.list_frame = tk.Frame(self.root, bg="#2c3e50")
        self.list_frame.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)

        # Add scrollbar to the list
        self.scrollbar = tk.Scrollbar(self.list_frame)
        self.scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # Create the list and define column headers
        self.tree = ttk.Treeview(self.list_frame, columns=("name", "genre", "status", "stars", "theme", "description"),
                                 show="headings", yscrollcommand=self.scrollbar.set)
        self.tree.heading("name", text="Name", command=lambda: self.sort("name"))
        self.tree.heading("genre", text="Genre", command=lambda: self.sort("genre"))
        self.tree.heading("status", text="Status", command=lambda: self.sort("status"))
        self.tree.heading("stars", text="Stars")
        self.tree.heading("theme", text="Theme")
        self.tree.heading("description", text="Description")

        # Set column widths
        self.tree.column("name", width=150, anchor="w")
        self.tree.column("genre", width=100, anchor="w")
        self.tree.column("status", width=100, anchor="w")
        self.tree.column("stars", width=100, anchor="w")
        self.tree.column("theme", width=100, anchor="w")
        self.tree.column("description", width=200, anchor="w")

        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.scrollbar.config(command=self.tree.yview)

        # Create a frame for the buttons (Delete, Update, Add, Save)
        self.button_frame = tk.Frame(self.root, bg="#dcab80", pady=5)
        self.button_frame.pack(pady=10, padx=10, fill=tk.X)

        # Add action buttons
        self.delete_button = tk.Button(self.button_frame, text="Delete", command=self.delete, bg="#e74c3c", fg="#ecf0f1",
                                    font=("Helvetica", 10))
        self.delete_button.pack(side=tk.LEFT, padx=10, pady=5)
        self.update_button = tk.Button(self.button_frame, text="Update", command=self.update, bg="#711f22",
                                         fg="#ecf0f1", font=("Helvetica", 10))
        self.update_button.pack(side=tk.LEFT, padx=10, pady=5)
        self.add_button = tk.Button(self.button_frame, text="Add", command=self.add, bg="#711f22", fg="#ecf0f1",
                                     font=("Helvetica", 10))
        self.add_button.pack(side=tk.LEFT, padx=10, pady=5)
        self.save_button = tk.Button(self.button_frame, text="Save", command=self.save_data, bg="#f39c12",
                                       fg="#ecf0f1", font=("Helvetica", 10))
        self.save_button.pack(side=tk.LEFT, padx=10, pady=5)

        # Add Review button
        self.review_button = tk.Button(self.button_frame, text="Review", command=self.review, bg="#c0392b",
                                       fg="#ecf0f1", font=("Helvetica", 10))
        self.review_button.pack(side=tk.LEFT, padx=10, pady=5)

        # Create a frame for the form fields
        self.form_frame = tk.Frame(self.root, bg="#ebdaca")
        self.form_frame.pack(pady=10, padx=10, fill=tk.X)

        # Add labels and entry boxes for form fields (Name, Genre, Status, etc.)
        self.name_label = tk.Label(self.form_frame, text="Name:", bg="#ebdaca", fg="#0b0b0b", font=("Helvetica", 10))
        self.name_label.grid(row=0, column=0, padx=5, pady=5)
        self.name_entry = tk.Entry(self.form_frame, bg="#ecf0f1", fg="#2c3e50", font=("Helvetica", 10))
        self.name_entry.grid(row=0, column=1, padx=5, pady=5)

        self.genre_label = tk.Label(self.form_frame, text="Genre:", bg="#ebdaca", fg="#0b0b0b", font=("Helvetica", 10))
        self.genre_label.grid(row=0, column=2, padx=5, pady=5)
        self.genre_combobox = ttk.Combobox(self.form_frame, values=["Memoir", "Novel", "Story", "Travel", "Poetry", "Biography", "Information", "Religion", "Children"], state="readonly")
        self.genre_combobox.grid(row=0, column=3, padx=5, pady=5)

        self.status_label = tk.Label(self.form_frame, text="Status:", bg="#ebdaca", fg="#0b0b0b", font=("Helvetica", 10))
        self.status_label.grid(row=1, column=0, padx=5, pady=5)
        self.status_combobox = ttk.Combobox(self.form_frame, values=["Read", "To Read", "Pending"],
                                           state="readonly")
        self.status_combobox.grid(row=1, column=1, padx=5, pady=5)

        self.stars_label = tk.Label(self.form_frame, text="Star Rating:", bg="#ebdaca", fg="#0b0b0b",
                                     font=("Helvetica", 10))
        self.stars_label.grid(row=1, column=2, padx=5, pady=5)
        self.stars_combobox = ttk.Combobox(self.form_frame, values=[1, 2, 3, 4, 5], state="readonly")
        self.stars_combobox.grid(row=1, column=3, padx=5, pady=5)

        self.theme_label = tk.Label(self.form_frame, text="Theme:", bg="#ebdaca", fg="#0b0b0b", font=("Helvetica", 10))
        self.theme_label.grid(row=2, column=0, padx=5, pady=5)
        self.theme_entry = tk.Entry(self.form_frame, bg="#ecf0f1", fg="#2c3e50", font=("Helvetica", 10))
        self.theme_entry.grid(row=2, column=1, padx=5, pady=5)

        self.description_label = tk.Label(self.form_frame, text="Description:", bg="#ebdaca", fg="#0b0b0b",
                                          font=("Helvetica", 10))
        self.description_label.grid(row=2, column=2, padx=5, pady=5)
        self.description_entry = tk.Entry(self.form_frame, bg="#ecf0f1", fg="#2c3e50", font=("Helvetica", 10))
        self.description_entry.grid(row=2, column=3, padx=5, pady=5)

    def filter(self):
        # Filter books based on search query and genre
        search_query = self.search_entry.get().lower()
        genre = self.search_genre_combobox.get()

        filtered_books = [book for book in self.book_list if
                          (search_query in book["name"].lower() or search_query in book["theme"].lower()) and
                          (genre == "All Genres" or genre == book["genre"])]

        self.update_list(filtered_books)

    def clear(self):
        # Clear search query and reset the list
        self.search_entry.delete(0, tk.END)
        self.search_genre_combobox.set("All Genres")
        self.update_list()

    def update_list(self, filtered_books=None):
        # Update the list based on filtered books or all books
        for item in self.tree.get_children():
            self.tree.delete(item)

        books_to_display = filtered_books if filtered_books else self.book_list

        for book in books_to_display:
            self.tree.insert("", "end", values=(book["name"], book["genre"], book["status"], book["stars"],
                                               book["theme"], book["description"]))

    def sort(self, column):
        # Sort the book list based on the selected column
        if self.reverse_sort:
            self.book_list.sort(key=lambda x: x[column], reverse=True)
        else:
            self.book_list.sort(key=lambda x: x[column])

        self.reverse_sort = not self.reverse_sort
        self.update_list()

    def add(self):
        # Add a new book to the list
        name = self.name_entry.get()
        genre = self.genre_combobox.get()
        status = self.status_combobox.get()
        stars = self.stars_combobox.get()
        theme = self.theme_entry.get()
        description = self.description_entry.get()

        if name and genre and status and stars and theme and description:
            self.book_list.append({
                "name": name,
                "genre": genre,
                "status": status,
                "stars": stars,
                "theme": theme,
                "description": description
            })
            self.update_list()
            messagebox.showinfo("Success", "The book has been successfully added.")
        else:
            messagebox.showerror("Error", "Please fill all fields.")

    def update(self):
        # Update selected book information
        selected_item = self.tree.selection()
        if selected_item:
            selected_book = self.tree.item(selected_item)["values"]
            self.name_entry.delete(0, tk.END)
            self.name_entry.insert(0, selected_book[0])

            self.genre_combobox.set(selected_book[1])
            self.status_combobox.set(selected_book[2])
            self.stars_combobox.set(selected_book[3])
            self.theme_entry.delete(0, tk.END)
            self.theme_entry.insert(0, selected_book[4])
            self.description_entry.delete(0, tk.END)
            self.description_entry.insert(0, selected_book[5])

    def delete(self):
        # Delete selected book
        selected_item = self.tree.selection()
        if selected_item:
            selected_book = self.tree.item(selected_item)["values"]
            self.book_list = [book for book in self.book_list if
                              book["name"] != selected_book[0] and book["theme"] != selected_book[4]]
            self.update_list()
            messagebox.showinfo("Deleted", "The book has been deleted.")
        else:
            messagebox.showerror("Error", "Please select a book to delete.")

    def review(self):
        # Show review for selected book
        selected_item = self.tree.selection()
        if selected_item:
            selected_book = self.tree.item(selected_item)["values"]
            messagebox.showinfo("Review", f"Review for {selected_book[0]}:\n\n{selected_book[5]}")
        else:
            messagebox.showerror("Error", "Please select a book to review.")

    def save_data(self):
        # Save book data to file
        try:
            with open("book_data.json", "w") as file:
                json.dump(self.book_list, file)
            messagebox.showinfo("Success", "Data saved successfully.")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred while saving data: {e}")

    def load_data(self):
        # Load book data from file
        try:
            with open("book_data.json", "r") as file:
                self.book_list = json.load(file)
            self.update_list()
        except FileNotFoundError:
            pass
        except json.JSONDecodeError:
            messagebox.showerror("Error", "Invalid data format in book data file.")

if __name__ == "__main__":
    root = tk.Tk()
    app = BookRecordApplication(root)
    root.mainloop()
